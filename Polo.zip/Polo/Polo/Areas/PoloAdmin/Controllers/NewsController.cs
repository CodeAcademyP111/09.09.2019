﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Polo.DAL;
using Polo.Models;

namespace Polo.Areas.PoloAdmin.Controllers
{
    [Area("PoloAdmin")]
    public class NewsController : Controller
    {
        private AppDbContext _context;
        public NewsController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View(_context.News);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(New news)
        {
            if (ModelState["Title"].ValidationState==Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Invalid ||
                ModelState["Content"].ValidationState == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Invalid) return View(news);

            string title = news.Title;
            string date = DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss");
            title += "-"+date;
            string sid = title.Replace(" ", "-");
            New newNews = new New
            {
                Title=news.Title,
                Content=news.Content,
                SId=sid
            };
            await _context.News.AddAsync(newNews);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }


        [Route("[area]/[controller]/[action]/{sid}")]
        public IActionResult Detail(string sid)
        {
            if (sid == null) return NotFound();

            New news=_context.News.FirstOrDefault(x=>x.SId==sid);
            if (news == null) return NotFound();

            return View(news);
        }
    }
}