﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Polo.Models
{
    public class Slider
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Required"), StringLength(150,ErrorMessage ="Length not more than 150 simbol")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Required"), StringLength(400, ErrorMessage = "Length not more than 400 simbol")]
        public string Description { get; set; }
        [Required,StringLength(255)]
        public string Image { get; set; }

        [NotMapped]
        [Required(ErrorMessage ="Required")]
        public IFormFile Photo { get; set; }

        [NotMapped]
        public IFormFile PhotoUpdate { get; set; }
    }
}
